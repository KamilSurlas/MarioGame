#pragma once
#include <Box2D.h>
#include "CollisionListener.h"
class CollisionListenerHelper
{
public:
	virtual void OnBeginContact(b2Fixture* other) = 0;
	virtual void OnEndContact(b2Fixture* other) = 0;
};


