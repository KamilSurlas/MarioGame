#include "Resources.h"
std::unordered_map<std::string, sf::Texture> Resources::textures{};
std::unordered_map<std::string, sf::SoundBuffer> Resources::sounds{};